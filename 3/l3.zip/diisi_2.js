l3file("https://cdn.statically.io/gh/hamdaniazzah/hamdaniazzah.github.io/master/l3/css/diisi_1.css", "css")
l3file("https://cdn.statically.io/gh/hamdaniazzah/hamdaniazzah.github.io/master/l3/js/diisi_1.js", "js")
