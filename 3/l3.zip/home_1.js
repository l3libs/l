l3file("https://cdn.statically.io/gh/hamdaniazzah/hamdaniazzah.github.io/master/l3/js/home_1.js", "js")
