l3file("https://hamdaniazzah.github.io/l3/css/post_lirik_2.css", "css")
l3file("https://hamdaniazzah.github.io/l3/js/post_lirik_3.js", "js")
l3file("https://cdn.ampproject.org/v0/amp-bind-0.1.js", "js")
